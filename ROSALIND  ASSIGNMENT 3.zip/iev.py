a, b, c, d, e, f = map(int, input().split())
r = (a + b + c) * 2 + d * 1.5 + e
print(r)