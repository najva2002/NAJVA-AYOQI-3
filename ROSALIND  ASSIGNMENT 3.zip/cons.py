file = open("dataset.txt", "r")
lines = file.read().split("\n")
lines = [line for line in lines if len(line) >= 1]

d = {"A": 0, "C": 1, "G": 2, "T": 3}
l = ["A", "C", "G", "T"]

mtx = None
created = False

i = 0
while i < len(lines):
    j = i + 1
    s = ""
    
    while j < len(lines) and lines[j].startswith(">") == False:
        s = s + lines[j]
        j = j + 1
        
    i = j
    
    if created == False:
        mtx = [[0 for i in range(len(s))] for j in range(4)]
        created = True
        
    for j in range(len(s)):
        mtx[d[s[j]]][j] += 1

res = ""
for i in range(len(mtx[0])):
    index = 0
    for j in range(4):
        if mtx[j][i] > mtx[index][i]:
            index = j

    res = res + l[index]
            
print(res)
print("A:", *mtx[0])
print("C:", *mtx[1])
print("G:", *mtx[2])
print("T:", *mtx[3])
        
