k, m, n = map(int, input().split())
a = []
b = []

for i in range(k):
    a.append("AA")
    
for i in range(m):
    a.append("Aa")

for i in range(n):
    a.append("aa")

for i in range(len(a)):
    for j in range(i + 1, len(a)):
        b.append(a[i][0] + a[j][0])
        b.append(a[i][0] + a[j][1])
        b.append(a[i][1] + a[j][0])
        b.append(a[i][1] + a[j][1])
        
c = 0

for i in range(len(b)):
    if "A" in b[i]:
        c = c + 1
        
print(c / len(b))