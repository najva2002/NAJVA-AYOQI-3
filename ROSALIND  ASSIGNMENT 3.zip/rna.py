t = input()
u = t.replace("T", "U")
print(u)