s = input()

s = s.replace("A", "t").replace("T", "A").replace("t", "T")
s = s.replace("C", "t").replace("G", "C").replace("t", "G")
s = s[::-1]

print(s)