s = input()

A = s.count("A")
C = s.count("C")
G = s.count("G")
T = s.count("T")

print(A, C, G, T)