file = open("dataset.txt", "r")
lines = file.read().split("\n")
lines = [line for line in lines if len(line) > 0]
comp = {}
    
current = ""
for i in range(len(lines)):
    if lines[i].startswith(">"):
        current = lines[i]
        comp[current] = ""
    else:
        comp[current] += lines[i]
        
string = None
max_gc = None

for key, value in comp.items():
    c = value.count("C")
    g = value.count("G")
    gc = (g + c) / len(value) * 100
    
    if max_gc is None or gc > max_gc:
        max_gc = gc
        string = key
        
print(string[1:])
print(max_gc)
