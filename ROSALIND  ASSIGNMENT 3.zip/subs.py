s = input()
t = input()
indexes = []

for i in range(len(s) - len(t) + 1):
    if s[i: i + len(t)] == t:
        indexes.append(i + 1)
        
print(*indexes)
        
